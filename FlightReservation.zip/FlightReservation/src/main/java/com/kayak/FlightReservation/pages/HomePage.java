package com.kayak.FlightReservation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.kayak.FlightReservation.base.TestBase;

public class HomePage extends TestBase {
	
	@FindBy(id="origin")
	WebElement origin;
	
	@FindBy(id="destination")
	WebElement destination;
	
	@FindBy(id="travel_dates-start-wrapper")
	WebElement departureDate;
	
	
	WebElement returnDate;
	
	
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	

}
