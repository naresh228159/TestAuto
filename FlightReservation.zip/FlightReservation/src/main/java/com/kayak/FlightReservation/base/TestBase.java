package com.kayak.FlightReservation.base;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestBase {
	
	public WebDriver driver;
	public Properties prop;
	
	public TestBase() {
		 InputStream is = null;
	     try {
	            this.prop = new Properties();
	            is = this.getClass().getResourceAsStream("/app.properties");
	            prop.load(is);
	     } catch (FileNotFoundException e) {
	            e.printStackTrace();
	     } catch (IOException e) {
	            e.printStackTrace();
	     }
		String browserName = prop.getProperty("browser");
			
		if(browserName.equals("chrome")){
			System.setProperty("webdriver.chrome.driver", "c://chromedriver//chromedriver.exe");	
			driver = new ChromeDriver(); 
		}
		else if(browserName.equals("FF")){
			System.setProperty("webdriver.gecko.driver", "c://geckodriver//geckodriver.exe");	
			driver = new FirefoxDriver(); 
		}		
		driver.manage().window().maximize();		
		driver.get(prop.getProperty("url"));	     
	}	
}
