package com.kayak.FlightReservation;

import com.kayak.FlightReservation.base.TestBase;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        TestBase tb = new TestBase();
    }
}
